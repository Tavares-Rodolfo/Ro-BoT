#!/bin/bash
#
#             |  Rodolfo Sodré Tavares                                                                          |
#             |  Biomédico                                                                                      |
#             |  Mestre pelo Programa de Pós-Graduação em Biologia da Relação Parasito-Hospedeiro - (PPGBRPH)   |
#             |  Instituto de Patologia Tropical e Saúde Pública - (IPTSP)                                      |
#             |  Universidade Federal de Goiás - (UFG)                                                          |
#             |  Doutorando pelo (PPGBRPH) - (IPTSP) - (UFG)                                                    |
#
# Script feito para automatizar as tarefas do cotidiano.
# Outros scripts menores dentro da pasta principal, são necessários pois servem de gatilho para executar outras ações.
#
# Para saber detalhes de cada comando, leia o REDAME ! WARNING
#
# Veja a lista de referências no final deste trabalho para ter acesso às fontes consultadas.
# Créditos e agradecimentos especiais: Aurélio Marinho Jargas, Ricardo Prudenciato e Slackjeff.
#
# FLUXOGRAMA
#                      INÍCIO                    FIM
#                   +-----------+            +----------+
#          +------> |    menu   |--Esc-----> |  sai do  |
#          |        | principal |--Cancel--> | programa |
#          |        +-----Ok----+       +--> +----------+
#          |              |             |
#          +--<--1 2 3-4--+--Zero--->---+
#
#
# Loop que mostra o menu principal
while : ; do

    # Mostra o menu na tela, com as ações disponíveis
    resposta=$(
      dialog --stdout                                                                          \
             --title 'Menu Ro-Bot'                                                             \
             --menu 'Olá, escolha uma opção para começar:'                                     \
            0 0 0                                                                              \
            1  "Sincronizar e Atualizar o Sistema (-Syu)"                                      \
            2  "Instalação de Programas em lote (pacman)"                                      \
            3  "Instalar Programas em lote (Flathub add + Flatpak)"                            \
            4  "Limpeza de arquivos Flatpak não utilizados"                                    \
            5  "Procurar por Pacotes"                                                          \
            6  "Instalação Manual"                                                             \
            7  "Desinstalação de pacotes (Recursivo + Dependências -Rs)"                       \
            8  "Fazer Backup [local] (/home)"                                                  \
            9  "Fazer Backup [ssh] (/home)"                                                    \
            10 "Restaurar Backup [local] (/home)"                                              \
            11 "Restaurar Backup [ssh] (/home)"                                                \
            12 "Adicionar rotina de Backup (/bin)"                                             \
            13 "Adicionar rotina de Backup [crontab] (Diário 12/18)"                           \
            14 "Mudar porta [ssh] e acesso root (22 to 2222 / root access denied on login)"    \
            15 "Salvar as configurações do Plasma [KDE]"                                       \
            16 "Restaurar as configurações do Plasma [KDE]"                                    \
            17 "Ajuda"                                                                         \
            18 "Sobre"                                                                         \
            19 "Sair")



#============================================================= INÍCIO DOS BLOCOS DE COMANDOS =============================================================
    case "$resposta" in
         1) sudo pacman -Syy && sudo pacman -Syu                                                                    ;;

#======================================================================== BLOCO 1 ========================================================================
         2) sudo pacman -S corectrl pdfarranger kolourpaint inkscape deepin-screenshot simple-scan catfish elisa kalarm kamoso akonadi-notes kshutdown                                                                                                                                  telegram-desktop vlc kalarm simplescreenrecorder
            sleep 4                                                                                                 ;;

#======================================================================== BLOCO 2 ========================================================================
         3) sudo pacman -S flatpak
            flatpak install flathub com.elsevier.MendeleyDesktop
            sleep 2
            flatpak install flathub com.giuspen.cherrytree
            sleep 2                                                                                                 ;;

#======================================================================== BLOCO 3 ========================================================================
         4) sudo flatpak uninstall --unused
            sleep 3                                                                                                 ;;

#======================================================================== BLOCO 4 ========================================================================
         5) echo -e "\e[33m Busca avançada de pacotes \e[33m"
            echo -e "\e[33m Por favor digite o nome do pacote para buscar \e[33m"
            read pacotes
            pacsearch "$pacotes"
            sleep 5                                                                                                 ;;

#======================================================================== BLOCO 5 ========================================================================
         6) echo -e "\e[33m O que você deseja instalar? \e[33m"
            read instalar
            sudo pacman -S "$instalar"
            sleep 3                                                                                                 ;;

#======================================================================== BLOCO 6 ========================================================================
         7) echo -e "\e[33m O que você deseja desinstalar? \e[33m"
            read desinstalar
            sudo pacman -Rs "$desinstalar"
            sleep 3                                                                                                 ;;

#======================================================================== BLOCO 7 ========================================================================
         8) echo -e "\e[33m Backup em andamento... \e[33m"
            sudo rsync -hav /home/ --log-file=Rsync_log --progress --delete --include=.config --exclude=.config/google-chrome/ --exclude=.config/iptvnator/ --exclude=.config/spotify --include=.cache/ --exclude=.cache/google-chrome/ --exclude=.cache/spotify --include=.local/ --exclude=.local/share/Steam/ --exclude=.local/share/Kingsoft/office6/ --exclude=.local/share/Trash/files/ --exclude=.steam/ --exclude=.V-Box-temp/ --exclude=.wine/ /run/media/rodolfo/7616ba71-acbe-4303-8c2c-d8452a1ec9f6/Fake\ home/
            sleep 3                                                                                                 ;;

#======================================================================== BLOCO 8 ========================================================================
         9) echo -e "\e[33m Backup em andamento... \e[33m"
            sudo rsync -havz --rsh='ssh -p2222' /home/ --log-file=Rsync_log --progress --delete --include=.config --exclude=.config/google-chrome/ --exclude=.config/spotify --exclude=.config/iptvnator/ --include=.cache/ --exclude=.cache/mozilla/ --exclude=.cache/google-chrome/ --exclude=.cache/wine/ --exclude=.cache/mesa_shader_cache/ --exclude=.cache/lutris/ --exclude=.cache/spotify/ --include=.local/ --exclude=.local/share/Steam/ --exclude=.local/share/lutris/ --exclude=.local/share/Kingsoft/office6/ --exclude=.local/share/Trash/files/ --exclude=.steam/ --exclude=.V-Box-temp/ --exclude=.wine/ $USER@192.168.11.17:/home
            sleep 3                                                                                                 ;;

#======================================================================== BLOCO 9 ========================================================================
         10) echo -e "\e[33m Restaurando Backup por favor aguarde... \e[33m"
            sudo rsync -hav /run/media/rodolfo/7616ba71-acbe-4303-8c2c-d8452a1ec9f6/Fake\ home/ --log-file=Rsync_log --progress --delete /home/
            sleep 3                                                                                                 ;;
            # Antes de saber se o backup é realmente restaurável adicione na lista de opções --dry-run (teste vazio) WARNING
            # $USER também pode ser substituido pelo seu nome de usuário

#======================================================================== BLOCO 10 =======================================================================
         11) echo -e "\e[33m Restaurando Backup por favor aguarde... \e[33m"
            sudo rsync -havz --log-file=Rsync_log --progress --delete --dry-run --rsh='ssh -p2222' /home/ $USER@192.168.11.17:/home
            sleep 3                                                                                                 ;;
            # Inicie o serviço SSH antes de tudo. Depois apenas mude o ip (host para hospedeiro). Teste com o comando --dry-run antes WARNING
            # $USER também pode ser substituido pelo seu nome de usuário

#======================================================================== BLOCO 11 =======================================================================
         12) echo -e "\e[33m Adicionando rotina de Backup \e[33m"
             sleep 2
             cd /home/$USER/Scripts/Ro-Bot/BackupRules/
             sudo ./Backup_trigger.sh
             echo -e "\e[33m Rotina de Backup adicionada com sucesso \e[33m"
             sleep 2                                                                                                 ;;

#======================================================================== BLOCO 12 =======================================================================
         13) echo -e "\e[33m Adicionando rotina de Backup a Crontab \e[33m"
             sleep 2
             cd /home/$USER/Scripts/Ro-Bot/CronRules/
             sudo ./cron_trigger.sh
             echo -e "\e[33m Rotina adicionada a Crontab com sucesso \e[33m"
             sleep 2                                                                                                ;;

#======================================================================== BLOCO 13 =======================================================================
         14) echo -e "\e[33m Mudando porta SSH \e[33m"
             sleep 2
             cd /home/$USER/Scripts/Ro-Bot/sshRules/
             sudo ./ssh_trigger.sh
             echo -e "\e[33m Mudanças efetuadas com sucesso \e[33m"
             sleep 2                                                                                                ;;
             # O comando abaixo também é funcional (modo manual) - Basta descomentar as linhas
             # cd /etc/ssh/
             # sudo nano sshd_config (salve e saia)

#======================================================================== BLOCO 14 =======================================================================
         15) echo -e "\e[33m Backup das configurações do KDE-Plasma \e[33m"
             sleep 2
             cd /home/$USER/Scripts/Ro-Bot/
             mkdir KDE-default
             cd /home/$USER/.config/
             sudo rsync -ahv --delete kwinrc /home/$USER/Scripts/Ro-Bot/KDE-default/
             sudo rsync -ahv --delete plasma-org.kde.plasma.desktop-appletsrc /home/$USER/Scripts/Ro-Bot/KDE-default/
             sudo rsync -ahv --delete /home/$USER/.config/kde.org /home/$USER/Scripts/Ro-Bot/KDE-default/
             sudo rsync -ahv --delete /home/$USER/.config/kdedefaults /home/$USER/Scripts/Ro-Bot/KDE-default/
             cd /home/$USER/Scripts/Ro-Bot/
             tar -cvf Backup.tar KDE-default/
             echo -e "\e[33m Guarde o backup feito em uma pasta segura para que o programa não o reescreva da próxima vez que você fizer uma nova cópia ! \e[33m"
             sleep 8                                                                                                 ;;

#======================================================================== BLOCO 15 =======================================================================
         16) echo -e "\e[33m Restaurando configurações do KDE-Plasma \e[33m"
             sleep 3
             cd /home/$USER/.config/
             sudo rm -rf kwinrc
             sudo rm -rf plasma-org.kde.plasma.desktop-appletsrc
             sudo rm -rf /home/$USER/.config/kde.org
             sudo rm -rf /home/$USER/.config/kde.org/kdedefaults
             cd /home/$USER/Scripts/Ro-Bot/KDE-default/
             sudo rsync -ahv /home/$USER/Scripts/Ro-Bot/KDE-default/kwinrc /home/$USER/.config/
             sudo rsync -ahv /home/$USER/Scripts/Ro-Bot/KDE-default/plasma-org.kde.plasma.desktop-appletsrc /home/$USER/.config/
             sudo rsync -ahv /home/$USER/Scripts/Ro-Bot/KDE-default/kde.org /home/$USER/.config/
             sudo rsync -ahv /home/$USER/Scripts/Ro-Bot/KDE-default/kdedefaults /home/$USER/.config/
             echo -e "\e[33m Restauração concluída com sucesso ! Por favor reinicie a sessão para aplicar as configurações. \e[33m"
             sleep 5
             echo -e "\e[33m Reiniciando a sessão agora. Para cancelar feche o terminal. \e[33m"
             sleep 5
             echo -e "\e[33m 5 \e[33m"
             sleep 1
             echo -e "\e[33m 4 \e[33m"
             sleep 1
             echo -e "\e[33m 3 \e[33m"
             sleep 1
             echo -e "\e[33m 2 \e[33m"
             sleep 1
             echo -e "\e[33m 1 \e[33m"
             sleep 1
             echo -e "\e[33m Saindo ... \e[33m"
             sleep 2
             sudo pkill -9 -u $USER                                                                                   ;;

#======================================================================== BLOCO 16 =======================================================================
         17)
echo -e "\e[33mEste é um script de automação com o objetivo de aumentar a eficiência do pós-instalação.
Foi pensado para funcionar no sistema Manjaro (Arch Linux), sendo facilmente portado para
outras distribuições, bastando apenas editar o seu código fonte. O mesmo encontra-se em
construção adicionar e/ou remover funções além de outras melhorias no código \e[33m"
             sleep 10                                                                                                 ;;

#======================================================================== BLOCO 17 =======================================================================
         18)
echo -e "\e[33mVersão: 1.0 (Ro-Bot)
Sobre: Feito por Rodolfo Tavares (Linux user !)
Contato: free_flying_@hotmail.com\e[33m"
             neofetch
             sleep 10                                                                                                 ;;

#======================================================================== BLOCO 18 =======================================================================
         19) echo -e "\e[33m Saindo.... \e[33m"
             sleep 0,5
             killall konsole                                                                                          ;;

#======================================================================== BLOCO 19 =======================================================================
#===================================================+============ FIM DOS BLOCOS DE COMANDOS =============================================================
    esac

done

echo
