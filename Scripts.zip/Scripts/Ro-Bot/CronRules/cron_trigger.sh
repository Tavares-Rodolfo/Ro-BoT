#!/bin/bash

sudo ./linux_cron.sh

echo
