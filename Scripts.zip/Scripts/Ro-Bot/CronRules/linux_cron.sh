#!/bin/bash

cd /etc/cron.d/
echo "SHELL=/bin/sh
PATH=/sbin:/bin:/usr/sbin:/usr/bin
MAILFROM=””
00 12,18 * * * root /usr/bin/Backup.sh" >> rodolfo_rotina_de_backup2.sh

echo
