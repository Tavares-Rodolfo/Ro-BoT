#!/bin/bash

sudo ./Backup.sh

echo
