#!/bin/bash

cd /bin/
echo "#!/bin/bash

sudo rsync -hav /home/ --log-file=Rsync_log --progress --delete --include=.config --exclude=.config/google-chrome/ --exclude=.config/iptvnator/ --exclude=.config/spotify --include=.cache/ --exclude=.cache/google-chrome/ --exclude=.cache/spotify --include=.local/ --exclude=.local/share/Steam/ --exclude=.local/share/Kingsoft/office6/ --exclude=.local/share/Trash/files/ --exclude=.steam/ --exclude=.V-Box-temp/ --exclude=.wine/ /run/media/rodolfo/9616ba71-ztrf-4209-6u9u-g7452a1ec1tf/Fake\ home/

echo" > Backup.sh
chmod +x Backup.sh

echo
