#!/bin/bash

cd /etc/ssh/
sudo cp -a /home/$USER/Scripts/Ro-Bot/sshRules/sshd_config /etc/ssh
sudo chmod +x sshd_config

echo
